# Rádio Espiritual Inteligente — API

Backend Node.js para plataforma de rádio espiritual com IA, canais, vozes TTS e programação automática.

## Pré-requisitos

- **Node.js 20+** → https://nodejs.org
- **pnpm** → `npm install -g pnpm`
- **PostgreSQL** rodando localmente ou em nuvem
- **Redis** (opcional — filas ficam indisponíveis sem Redis)

## Passo a passo para rodar

### 1. Instalar dependências

```bash
pnpm install
```

### 2. Configurar variáveis de ambiente

```bash
cp .env.example .env
```

Abra o arquivo `.env` e preencha:

```env
NODE_ENV=development
PORT=3000

# Obrigatório: URL do seu PostgreSQL
DATABASE_URL=postgresql://usuario:senha@localhost:5432/radio_espiritual

# Obrigatório: qualquer string longa e aleatória
JWT_SECRET=coloque-uma-chave-secreta-aqui

# Opcional: só necessário se tiver Redis rodando
REDIS_URL=redis://localhost:6379
```

### 3. Criar o banco de dados PostgreSQL

No terminal do PostgreSQL (psql):

```sql
CREATE DATABASE radio_espiritual;
```

> O projeto cria as tabelas automaticamente na primeira execução.

### 4. Compilar e rodar

```bash
# Compilar TypeScript → JavaScript
pnpm run build

# Iniciar o servidor
pnpm run start
```

Ou rodar os dois de uma vez:

```bash
pnpm run build && pnpm run start
```

### 5. Verificar se está funcionando

Abra no navegador ou via curl:

```
http://localhost:3000/api/healthz     → { "status": "ok" }
http://localhost:3000/api/docs        → Swagger UI (documentação interativa)
```

## Endpoints principais

| Método | Rota | Descrição |
|--------|------|-----------|
| POST | /api/auth/register | Criar conta |
| POST | /api/auth/login | Login (retorna JWT) |
| GET | /api/contents | Listar conteúdos |
| GET | /api/radio/current | Conteúdo atual na rádio |
| GET | /api/voices | Vozes disponíveis |

> Todos os endpoints (exceto auth e radio) precisam do header: `Authorization: Bearer <token>`

## Instalar PostgreSQL localmente (se necessário)

- **Windows**: https://www.postgresql.org/download/windows/
- **macOS**: `brew install postgresql && brew services start postgresql`
- **Linux**: `sudo apt install postgresql && sudo systemctl start postgresql`

## Instalar Redis localmente (opcional)

- **Windows**: https://github.com/microsoftarchive/redis/releases
- **macOS**: `brew install redis && brew services start redis`
- **Linux**: `sudo apt install redis-server && sudo systemctl start redis`
